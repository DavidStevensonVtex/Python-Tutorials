The rain in Spain falls mainly in the plain.
