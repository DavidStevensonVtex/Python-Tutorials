# tarfile_is_tarfile.py
import tarfile

for filename in ["README.txt", "example.tar", "bad_example.tar", "notthere.tar"]:
    try:
        print("{:>15}  {}".format(filename, tarfile.is_tarfile(filename)))
    except IOError as err:
        print("{:>15}  {}".format(filename, err))
